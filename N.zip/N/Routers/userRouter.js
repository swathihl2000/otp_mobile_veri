const router=require('express');
const{ signUp, verfyOtp }=require('../Controllers/userController');

router('/signup')
.post(signUp);
router('/signup/verify')
.post(verfyOtp);

module.exports=router;